var builder = WebApplication.CreateBuilder(args);
var allowedOrigins = (Environment.GetEnvironmentVariable("GOSPHERE_ALLOWED_ORIGINS") ?? "")
    .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
builder.Services.AddCors(options => options.AddDefaultPolicy(policy =>
{
    if (allowedOrigins.Length > 0) policy.WithOrigins(allowedOrigins).AllowAnyHeader().AllowAnyMethod();
}));
var app = builder.Build();
app.UseHttpsRedirection();
if (allowedOrigins.Length > 0) app.UseCors();
app.MapGet("/health", () => Results.Ok(new { status = "ok", app = "GOSPHERE API", stage = "development-starter" }));
// These endpoints intentionally return empty live data: no fabricated/demo providers are seeded.
app.MapGet("/api/v1/trucks", () => Results.Ok(new { items = Array.Empty<object>() }));
app.MapGet("/api/v1/providers", (string? type) => Results.Ok(new { type, items = Array.Empty<object>() }));
app.MapGet("/api/v1/nearby", (string? type, double? latitude, double? longitude) =>
    Results.Ok(new { type, items = Array.Empty<object>() }));
app.MapPost("/api/v1/auth/register", () => Results.Problem(
    "Account registration is not enabled until PostgreSQL persistence, password hashing, validation and phone verification are configured.",
    statusCode: StatusCodes.Status501NotImplemented));
app.MapPost("/api/v1/auth/login", () => Results.Problem(
    "Login is not enabled until persistent accounts and secure password verification are configured.",
    statusCode: StatusCodes.Status501NotImplemented));
app.MapPost("/api/v1/vehicles", () => Results.Problem(
    "Vehicle listing submission is not enabled until authenticated database storage and moderation are configured.",
    statusCode: StatusCodes.Status501NotImplemented));
app.Run();
