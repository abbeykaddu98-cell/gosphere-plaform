# GOSPHERE — Hybrid Technologies Company

This package is a rebranded and partially updated frontend/API starter based on the supplied TruckMan source.

## Included
- GOSPHERE branding and home navigation
- Buy/sell vehicle entry screen
- Nearby screen available to every service type, with user-initiated browser geolocation and Google Maps embed
- Show/hide password controls on registration and login
- Username/password login interface (API integration point)
- Settings navigation and account controls
- API starter with health, search, nearby, registration, login and vehicle endpoints
- No hardcoded demo provider accounts or sample provider records

## Important implementation status
This is **not production-ready**. The API deliberately returns empty provider collections and responds with HTTP 501 for registration, login and vehicle submission until secure PostgreSQL persistence, password hashing, authorization, phone verification, moderation and payment integrations are implemented. No fake success is returned.

The map centers Google Maps on the user's location but actual provider pins require real approved provider records with consented coordinates from the backend. Google Maps API key-based advanced map functionality and billing setup may be required for further features.

## Configure API
Set `GOSPHERE_API_BASE` in `www/index.html` via a deployment config script or set `window.GOSPHERE_API_BASE` before `app.js` loads. Configure `GOSPHERE_ALLOWED_ORIGINS` on the API to a comma-separated list of exact HTTPS origins. Do not use wildcard CORS in production.

## Security work still required before public launch
- PostgreSQL schema/migrations and parameterized data access
- Password hashing (Argon2id or PBKDF2), login throttling and secure session/token lifecycle
- Server-side validation and role-based authorization
- Admin-only application and audited administrative operations
- Phone/email verification and account recovery
- Payment provider integrations and webhook signature verification
- Upload scanning, file type/size limits and storage isolation
- Rate limiting, security headers, secrets management, backups and penetration testing
- Legal/privacy review for launch countries

Never commit database URLs, passwords, signing keys, API keys or payment credentials to source control.
